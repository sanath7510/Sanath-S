#!/bin/bash
# Example usage (after installing requirements)
# Encrypt a text string:
python src/main.py --mode encrypt --key "strongpasswordhere" --in "Secret message" --out encrypted.bin --type text
# Decrypt the text:
python src/main.py --mode decrypt --key "strongpasswordhere" --in encrypted.bin --out decrypted.txt --type text
# Encrypt a file:
python src/main.py --mode encrypt --key "strongpasswordhere" --in examples/sample.txt --out examples/encrypted_file.bin --type file
# Decrypt a file:
python src/main.py --mode decrypt --key "strongpasswordhere" --in examples/encrypted_file.bin --out examples/decrypted_sample.txt --type file
