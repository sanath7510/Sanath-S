from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes
import os
from typing import Tuple

SALT_SIZE = 16
NONCE_SIZE = 12  # recommended for GCM
KEY_LEN = 32  # AES-256
PBKDF2_ITERS = 100_000

def derive_key(password: str, salt: bytes = None) -> Tuple[bytes, bytes]:
    """Derive a 32-byte key from a password using PBKDF2. Returns (key, salt)."""
    if salt is None:
        salt = get_random_bytes(SALT_SIZE)
    key = PBKDF2(password, salt, dkLen=KEY_LEN, count=PBKDF2_ITERS)
    return key, salt

def encrypt_bytes(key: bytes, plaintext: bytes) -> bytes:
    """Encrypt bytes with AES-GCM. Returns concatenated: salt|nonce|tag|ciphertext"""
    nonce = get_random_bytes(NONCE_SIZE)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    return nonce + tag + ciphertext

def decrypt_bytes(key: bytes, data: bytes) -> bytes:
    """Decrypt bytes with AES-GCM given data == nonce|tag|ciphertext"""
    nonce = data[:NONCE_SIZE]
    tag = data[NONCE_SIZE:NONCE_SIZE+16]
    ciphertext = data[NONCE_SIZE+16:]
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    return plaintext

def encrypt_file_with_password(password: str, in_path: str, out_path: str) -> None:
    """Derive key from password, write salt + encrypted payload to out_path."""
    key, salt = derive_key(password)
    with open(in_path, 'rb') as f:
        plaintext = f.read()
    payload = encrypt_bytes(key, plaintext)
    with open(out_path, 'wb') as f:
        f.write(salt + payload)

def decrypt_file_with_password(password: str, in_path: str, out_path: str) -> None:
    with open(in_path, 'rb') as f:
        filedata = f.read()
    salt = filedata[:SALT_SIZE]
    payload = filedata[SALT_SIZE:]
    key, _ = derive_key(password, salt)
    plaintext = decrypt_bytes(key, payload)
    with open(out_path, 'wb') as f:
        f.write(plaintext)

def encrypt_text_with_password(password: str, text: str) -> bytes:
    key, salt = derive_key(password)
    payload = encrypt_bytes(key, text.encode('utf-8'))
    return salt + payload

def decrypt_text_with_password(password: str, data: bytes) -> str:
    salt = data[:SALT_SIZE]
    payload = data[SALT_SIZE:]
    key, _ = derive_key(password, salt)
    plaintext = decrypt_bytes(key, payload)
    return plaintext.decode('utf-8')
