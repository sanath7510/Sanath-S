import argparse
from crypto_utils import encrypt_file_with_password, decrypt_file_with_password, encrypt_text_with_password, decrypt_text_with_password
import sys
import os

def main():
    parser = argparse.ArgumentParser(description='AES-GCM encrypt/decrypt utility (password-derived key).')
    parser.add_argument('--mode', choices=['encrypt','decrypt'], required=True)
    parser.add_argument('--key', required=True, help='Password to derive AES key (use a secure random 32-byte key in production)')
    parser.add_argument('--in', dest='inpath', required=True, help='Input file path or text (when --type=text)')
    parser.add_argument('--out', dest='outpath', required=True, help='Output file path (for decrypt) or output filename (for encrypt)')
    parser.add_argument('--type', choices=['file','text'], default='file', help='Type of input')
    args = parser.parse_args()

    if args.type == 'text':
        if args.mode == 'encrypt':
            data = encrypt_text_with_password(args.key, args.inpath)
            with open(args.outpath, 'wb') as f:
                f.write(data)
            print(f'Encrypted text written to {args.outpath}')
        else:
            with open(args.inpath, 'rb') as f:
                data = f.read()
            text = decrypt_text_with_password(args.key, data)
            with open(args.outpath, 'w', encoding='utf-8') as f:
                f.write(text)
            print(f'Decrypted text written to {args.outpath}')
    else:
        if args.mode == 'encrypt':
            encrypt_file_with_password(args.key, args.inpath, args.outpath)
            print(f'File encrypted -> {args.outpath}')
        else:
            decrypt_file_with_password(args.key, args.inpath, args.outpath)
            print(f'File decrypted -> {args.outpath}')

if __name__ == '__main__':
    main()
