import os
from crypto_utils import encrypt_text_with_password, decrypt_text_with_password

def test_roundtrip():
    pwd = 'testpassword123'
    text = 'Hello unit test!'
    data = encrypt_text_with_password(pwd, text)
    assert isinstance(data, (bytes, bytearray))
    out = decrypt_text_with_password(pwd, data)
    assert out == text
    print('test_roundtrip passed.')

if __name__ == '__main__':
    test_roundtrip()
